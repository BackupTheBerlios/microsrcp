/**
 config.h - Zentrale Konfiguration von BiDiB System, darf nur
 einmal im Main Programm included werden.

 Copyright (c) 2013 Marcel Bernet.  All right reserved.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef BOARD
 #warning SEVERE Warning - please define a BOARD
 #warning config.h for explanations
 // use following statements in your Main Programm
 // #define BOARD_my_new_hardware 5
 // #define BOARD BOARD_my_new_hardware
#else
	#if ( BOARD == BOARD_MICRO_GL )

        #define   BIDIB_VENDOR_ID        1
        #define   BIDIB_PRODUCT_ID      1     // see www.opendcc.de/elektronik/bidib
		#define   CLASS_BOOSTER			  1		// Booster
        #define   CLASS_ACCESSORY         1     // 0: no accessory messages, 1: accessory messages included
        #define   CLASS_OCCUPANCY         1     // 0: no occupancy messages, 1: occupancy messages included
        #define   CLASS_SWITCH            1     // 0: no switch messages, 1: switch messages included
    #else
        #error wrong BOARD
    #endif
#endif

#include <srcp/SRCPDevice.h>
#include <srcp/SRCPDeviceManager.h>
#include "BiDiBSession.h"
#include "BiDiBInterfaceSerial.h"

#ifdef CLASS_ACCESSORY
#include "BiDiBAccessorySystem.h"
#include <dev/GASignal.h>
#include <dev/GAServo.h>
#include <dev/GAPWMServo.h>
#endif
#ifdef CLASS_OCCUPANCY
#include "BiDiBOcccupancySystem.h"
#include <dev/FBSwitchSensor.h>
#endif
#ifdef CLASS_BOOSTER
#include "BiDiBCSSystem.h"
#include <dev/GLArduinoMotor.h>
#endif

/**
 * Arduino Unique Id
 */
const bidib::t_bidib_myunique_id myUniqueId =
{
	{
			CLASS_SWITCH, 		// mit Switches
			CLASS_BOOSTER, 		// Booster
			CLASS_ACCESSORY,  	// Zubehoer
			1,  				// DCC Signal
			0,  				// DCC Programmer
			0,  				// UI
			CLASS_OCCUPANCY,  	// Belegtmeldern
			0,   				// Bridge
	},
	0,
	BIDIB_VENDOR_ID,
	{
		BIDIB_PRODUCT_ID,
		7,
	}
};

/**
 * SYS Magic - Startmeldung
 */
const uint8_t bidib_sys_magic[] = // this is our answer for SYS_MAGIC
{
		5, // size
		0x00, // addr
		0x00, // msg_num
		MSG_SYS_MAGIC,
		BIDIB_SYS_MAGIC & 0xFF,
		(BIDIB_SYS_MAGIC >> 8) & 0xFF,
};


