/**
 BiDiBSubSystem - Hauptklasse fuer alle BiDiB Subsysteme

 Copyright (c) 2013 Marcel Bernet.  All right reserved.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef BIDIBSUBSYSTEM_H_
#define BIDIBSUBSYSTEM_H_

#include <Arduino.h>
#include "bidib_messages.h"
#include "bidib_datatypes.h"
#include "../srcp/SRCPCommand.h"
#include "../srcp/SRCPDeviceManager.h"

namespace bidib
{

class BiDiBSubSystem
{
protected:
	//BiDiBSession* session;
	BiDiBSubSystem *next;
	uint8_t rc[2];
public:
	void setNextElement( BiDiBSubSystem* next ) { this->next = next; }
	BiDiBSubSystem* nextElement() { return ( next ); }
	virtual int dispatch( uint8_t* msg );
	virtual int getFeatureCount() { return ( 0 ); }
	virtual t_feature* getFeatures();
	virtual uint8_t* getFeatureByIndex( int index );
	virtual uint8_t* getFeature( uint8_t type );
	virtual uint8_t* setFeature( uint8_t index, uint8_t value );
	// meldet Aenderungen an die abgeleiteten Klassen. Der Returnwert in [1] ist der neue Wert in [0] der Alte
	virtual uint8_t fireFeatureChange( uint8_t oldValue, uint8_t newValue ) { return( newValue ); }
};

} /* namespace bidib */
#endif /* BIDIBSUBSYSTEM_H_ */
