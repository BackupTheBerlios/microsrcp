/**
 BiDiBOccupancySystem - Abhandlung von Belegtmelder Befehlen

 Copyright (c) 2013 Marcel Bernet.  All right reserved.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "BiDiBOcccupancySystem.h"
#include <Streaming.h>

namespace bidib
{

// am Node 0 habe wir wenig features ... nur Melderbits
t_feature feature_occupancy[] =
{   // num                               value default
     { FEATURE_BM_SIZE,                   8,    8  },  // Anzahl der Belegtmelder = Eingaenge nicht S88 o.ae.
     { FEATURE_BM_ON,                     1,    1  },  // 1 = Der Knoten liefert Belegtmeldungen (Spontan). Dies erfolgt automatisch bei einer �nderung des Zustandes.
     { FEATURE_BM_SECACK_AVAILABLE,       0,    0  },  // 1 = Der Melder beherscht das Secure-ACK-Quittungsverfahren f�r Belegtmeldungen
     { FEATURE_BM_SECACK_ON,              0,    0  },  // 1 = Secure-ACK-Quittungsverfahren enabled
     { FEATURE_BM_ADDR_DETECT_AVAILABLE,  0,    0  },  // 1 = Der Melder kann erkannte Lok-Adressdaten liefern (sofern im Lokdekoder aktiviert)
     { FEATURE_BM_ADDR_DETECT_ON,         0,    0  },  // 1 = Der Melder liefert die Adressdaten
     { FEATURE_BM_ADDR_AND_DIR,           0,    0  },  // 1 = Der Melder hat Richtungserkennung, d.h. die prinzipielle F�higkeit dazu.
     { FEATURE_BM_CV_AVAILABLE,           0,    0  },  // 1 = Der Melder kann CV-Antworten von Dekodern einlesen
     { FEATURE_BM_CV_ON,                  0,    0  },  // 1 = Der Melder leitet CV-Antworten des Dekoders weiter
};

BiDiBOccupancySystem::BiDiBOccupancySystem( BiDiBSession* session )
{
	this->session = session;
	last = 0;
}

int BiDiBOccupancySystem::dispatch( uint8_t* buf )
{
	// Befehl abhandeln
	switch	( buf[2] )
	{
		// Belegtmelder abfragen von Start- bis End-Position (0x20)
		case	MSG_BM_GET_RANGE:
			sendOccupancyResponse( buf[0], buf[3] );
			break;
	}
	return	( 1 );
}

int BiDiBOccupancySystem::sendOccupancyResponse( int bus, int addr )
{
	// Command
	srcp::command_t cmd;

	cmd.cmd = srcp::GET;
	cmd.bus = bus;
	cmd.device = srcp::FB;
	cmd.addr= addr + 1;
	session->getManager()->dispatch( cmd );

	// Hack: nur Senden wenn nichts veraendert
	if	( last != cmd.values[0] )
	{
#if ( DEBUG_SCOPE > 1 )
	Serial3 << "FB: " << cmd.addr << " = " << cmd.values[0] << endl;
#endif

		t_node_message18 msg10;
		msg10.header.node_addr = 0;
		msg10.header.index = session->getNextIndex();
		msg10.header.msg_type = MSG_BM_MULTIPLE;
		msg10.data[0] = 0;							// Start Index Eingaenge - fix
		msg10.data[1] = 8;							// Anzahl Eingaenge nicht S88 o.ae. - fix
		msg10.header.size = 3+2+1;
		last = msg10.data[2] = cmd.values[0];		// Belegtmeldungen als Bit's, ein Eingang = 1 Bit
		session->sendResponse( (uint8_t *) &msg10 );
		// doppelt haelt besser!
		session->sendResponse( (uint8_t *) &msg10 );
		return	( 1 );
	}
	return	( 1 );
}


int BiDiBOccupancySystem::getFeatureCount()
{
	return	( sizeof(feature_occupancy)/sizeof(feature_occupancy[0]) );
}

t_feature* BiDiBOccupancySystem::getFeatures()
{
	return	( feature_occupancy );
}

} /* namespace bidib */
