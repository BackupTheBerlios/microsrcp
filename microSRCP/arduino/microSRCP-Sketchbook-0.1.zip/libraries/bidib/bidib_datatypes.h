/**
 BiDiBSession - BiDiB Datatypes

 Copyright (c) 2013 Marcel Bernet.  All right reserved.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef BIDIB_DATATYPES_H_
#define BIDIB_DATATYPES_H_

#define VERSION           0      // sw version
#define SUBVERSION       12      // sub version
#define COMPILE_RUN       5      // sub-sub version

namespace bidib
{

/**
 * Struktur mit den Eigenschaften des BiDiB Geraetes.
 */
typedef struct
{
	struct
	{
		unsigned char class_switch :1;
		unsigned char class_booster :1;
		unsigned char class_accessory :1;
		unsigned char class_dcc_prog :1;
		unsigned char class_dcc_main :1;
		unsigned char class_ui :1;
		unsigned char class_occupancy :1;
		unsigned char class_bridge :1;
	};
	unsigned char classx_id;
	unsigned char dcc_vendor;
	struct
	{
		unsigned int product_id;
		unsigned int product_serial;
	};
} t_bidib_myunique_id;

//-------------------------------------------------------------------------------
//
// useful typedefs for bidib messages (flat addressing)

typedef struct
{
	unsigned char size;
	unsigned char node_addr;
	unsigned char index;
	unsigned char msg_type;
} t_node_message_header;

typedef struct
{
	t_node_message_header header;
	unsigned char data;
} t_node_message1;

typedef struct
{
	t_node_message_header header;
	unsigned char data[2]; // be sure, not to load more data here!
} t_node_message2;

typedef struct
{
	t_node_message_header header;
	unsigned char data[10];
} t_node_message10;

typedef struct
{
	t_node_message_header header;
	unsigned char data[18];
} t_node_message18;

typedef enum
{
	BIDIB_DISCONNECTED = 0x00, // nach Einschalten
	BIDIB_APPLIED = 0x01, // Logon abgesendet, wir warten auf ACK
	BIDIB_CONNECTED = 0x02, // Verbunden
} bidib_connect_t;

//-------------------------------------------------------------------------------
// Feature-Handling
//
// Fuer features haben wir hier eine Tabelle, in der wir das angefragte feature
// suchen: wenn es vorhanden ist, dann wird es zurueckmeldet.
// Beim Setzen eines Features vergleichen wir auf die Grenzen (min, max) und rufen
// bei Veraenderungen die notify_function auf, damit die Veraenderung auch wirkt.
//
// --> Zum Hinzufuegen weiterer features einfach die Tabelle erweitern!
//     Es gibt einen #define (mit der Endung _idx), dieser mu� durchlaufend
//     numeriert sein, �ber diesen
//     define werden die features lokal angesprochen. F�r den remote-Zugriff ist
//     die verpflichtende Featurenummer als erster Eintrag abgespeichert.
// --> Nicht benoetige Features kann man einfach weglassen

typedef struct
{
	unsigned char num; // feature index
	unsigned char value; // der aktuelle Wert
	unsigned char def; // Default Wert
} t_feature;

}

#endif /* BIDIB_DATATYPES_H_ */
