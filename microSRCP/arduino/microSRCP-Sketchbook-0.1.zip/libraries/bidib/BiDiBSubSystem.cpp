/**
 BiDiBSubSystem - Hauptklasse fuer alle BiDiB Subsysteme

 Copyright (c) 2013 Marcel Bernet.  All right reserved.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "BiDiBSubSystem.h"

namespace bidib
{

uint8_t* BiDiBSubSystem::getFeatureByIndex( int index )
{
	if	( index >= 0 && index < getFeatureCount( ))
	{
		rc[0] = getFeatures()[index].num;
		rc[1] = getFeatures()[index].value;
		return	( rc );
	}
	return	( (uint8_t*) 0 );
}

uint8_t* BiDiBSubSystem::getFeature( uint8_t type )
{
	for	( int index = 0; index < getFeatureCount(); index++ )
	{
		if	( getFeatures()[index].num == type )
			return	( getFeatureByIndex( index ));
	}
	return	( (uint8_t*) 0 );
}

uint8_t* BiDiBSubSystem::setFeature( uint8_t type, uint8_t value )
{
	for	( int index = 0; index < getFeatureCount(); index++ )
	{
		if	( getFeatures()[index].num == type )
		{
			rc[0] = getFeatures()[index].value;
			rc[1] = value;
			getFeatures()[index].value = rc[1] = fireFeatureChange( rc[0], rc[1] );
			return	( rc );
		}
	}
	return	( (uint8_t*) 0 );
}

}




