/**
 BiDiBAccessorySystem - Abhandlung von Zentrale (Fahrbefehlen) Befehlen

 Copyright (c) 2013 Marcel Bernet.  All right reserved.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "BiDiBCSSystem.h"
#include <Streaming.h>

namespace bidib
{

t_feature feature_cs[] =
{   //  num                            value min max notify_function (if changed)
	{ FEATURE_FW_UPDATE_MODE,           0,    0 },  // 0: kein FW-Update m�glich
};

BiDiBCSSystem::BiDiBCSSystem( BiDiBSession* session )
{
	this->session = session;
}

int BiDiBCSSystem::dispatch( uint8_t* buf )
{
	// Command
	srcp::command_t cmd;

	// Befehl abhandeln
	switch	( buf[2] )
	{

	//------------------------------------------------- Class Lokomotiven (GL)
	// Lok Fahrbefehl (0x64) 1:addrl, 2:addrh, 3:format, 4:active, 5:speed, 6:1-4, 7:5-12, 8:13-20, 9:21-28
	case MSG_CS_DRIVE:
		cmd.cmd = srcp::SET;
		cmd.bus = buf[0];
		cmd.device = srcp::GL;
		cmd.addr = (buf[4] * 256) + buf[3];
		cmd.values[0] = ((buf[7] & 0x80) != 0) ? 1 : 0; 		// Fahrrichtung
		cmd.values[1] = buf[7] & 0x7F;							// Geschwindigkeit
		cmd.values[3] = ((buf[8] & 0x10) != 0) ? 1 : 0;			// FLicht
		cmd.values[4] = buf[8] & 0x0F;   					    // F1 - F4
		cmd.values[2] = 127;									// Max. Geschwindigkeit - wird bei BiDiB nicht gesendet, Deshalb fix
#if	( DEBUG_SCOPE > 1 )
Serial3 << "set GL: " << cmd.addr << ", " << cmd.values[0] << ", " << cmd.values[1] << ":" << cmd.values[2] << ", " << cmd.values[3] << ":" << cmd.values[4] << endl;
#endif
		session->getManager()->dispatch( cmd );

		// Response ob Befehl erfolgreich
		t_node_message10 message;
	    message.header.node_addr = 0;
	    message.header.index = session->getNextIndex();
	    message.header.msg_type = MSG_CS_DRIVE_ACK;
	    message.data[0] = buf[3];
        message.data[1] = buf[4];
        message.data[2] = 1;				 // Sofortige Quittung: Befehl wurde angenommen und wird demn�chst auf das Gleis ausgegeben.
        message.header.size = 3+3;
        session->sendResponse( (uint8_t*) &message );
		break;
	}
	return	( 1 );
}

int BiDiBCSSystem::getFeatureCount()
{
	return	( sizeof(feature_cs)/sizeof(feature_cs[0]) );
}

t_feature* BiDiBCSSystem::getFeatures()
{
	return	( feature_cs );
}

} /* namespace bidib */
