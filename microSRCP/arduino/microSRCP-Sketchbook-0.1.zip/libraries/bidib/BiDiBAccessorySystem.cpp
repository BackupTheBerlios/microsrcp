/**
 BiDiBAccessorySystem - Abhandlung von Zubehoer Befehlen

 Copyright (c) 2013 Marcel Bernet.  All right reserved.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "BiDiBAccessorySystem.h"

namespace bidib
{

t_feature feature[] =
{    //  num                            value default
     { FEATURE_CTRL_INPUT_COUNT,         0,    0},  // Anzahl der Eing�nge (z.B. f�r Taster)
     { FEATURE_CTRL_INPUT_NOTIFY,        0,    0},  // Spontan-Meldung von Taster-Eing�ngen erlaubt. Der Knoten liefert �nderungen des Tasterzustand von selbst an den Host.
     { FEATURE_CTRL_SPORT_COUNT,         0,    0},  // Anzahl der Standard-Ausg�nge
     { FEATURE_CTRL_LPORT_COUNT,         32,  32},  // Anzahl der Licht-Ausg�nge
     { FEATURE_CTRL_SERVO_COUNT,         8,    8},  // Anzahl der Servoausg�nge
     { FEATURE_CTRL_MAC_LEVEL,           0,    0},  // Unterst�tzter Makro-Level - 0 = keine Makrof�higkeit

     { FEATURE_ACCESSORY_COUNT,          32,  32},  // Anzahl der Weichen / Signale
     { FEATURE_ACCESSORY_SURVEILLED,     0,    0},  // Lage-�berwachung - 1: Knoten meldet bei Handverstellung den neuen Zustand mit einer MS_ACCESSORY_STATE Nachricht.
     { FEATURE_ACCESSORY_MACROMAPPED,    0,    0},  // Abbildung von Begriffen auf Macros - 0 = keine
};

BiDiBAccessorySystem::BiDiBAccessorySystem( BiDiBSession* session )
{
	this->session = session;
}

int BiDiBAccessorySystem::dispatch( uint8_t* buf )
{
	// Command
	srcp::command_t cmd;

	// Befehl abhandeln
	switch	( buf[2] )
	{

		// Zubehoer setzen (0x38)
		case MSG_ACCESSORY_SET:
			cmd.cmd = srcp::SET;
			cmd.bus = buf[0];
			cmd.device = srcp::GA;
			cmd.addr = buf[3] + 1;
			cmd.values[0] = cmd.values[1] = buf[4];
			cmd.values[2] = 0;
			session->getManager()->dispatch( cmd );

			// Response ob Befehl erfolgreich
		    t_node_message10 message;
		    message.header.node_addr = 0;
		    message.header.index = session->getNextIndex();
		    message.header.msg_type = MSG_ACCESSORY_STATE;
		    message.data[0] = buf[3];
	        message.data[1] = 0;
	        message.data[2] = 2;				 // Anzahl Zustaende - fix 2
	        message.data[3] = (1<<1) | (0<<0);   // kein feedback / fertig
	        message.data[4] = 0;                 // no wait
	        message.header.size = 3+5;
	        session->sendResponse( (uint8_t*) &message );
			break;
	}
	return	( 1 );
}

int BiDiBAccessorySystem::getFeatureCount()
{
	return	( sizeof(feature)/sizeof(feature[0]) );
}

t_feature* BiDiBAccessorySystem::getFeatures()
{
	return	( feature );
}

} /* namespace bidib */
