/**
 BiDiBInterfaceSerial - Serielle BiDiB Kommunikation an Port 1 (Pin 0, 1)

 Copyright (c) 2013 Marcel Bernet.  All right reserved.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "BiDiBInterfaceSerial.h"
#include <Streaming.h>

namespace bidib
{
#if	( DEBUG_SCOPE > 1 )
char str[10];

char* hex( uint8_t x )
{
	sprintf( str, "%x ", x );
	return	( str );
}
#endif

/**
 * Oeffnet den Seriallen Port mit speed, 8 bit, No Parity und 1 Stop Bit.
 * Flow/Control unterstuetzt das Arduino Port.
 */
void BiDiBInterfaceSerial::begin(unsigned long speed)
{
#if	( DEBUG_SCOPE > 1 )
	Serial3 << "open port 1: " << speed << endl;
#endif
	Serial.begin( speed );
}

/**
 * Prueft ob Daten am Seriellen Port anliegt und wenn ja wird ein Pointer auf die gelesene
 * Array zurueckgegeben sonst null.
 */
uint8_t* BiDiBInterfaceSerial::available(void)
{
	// keine Daten vorhanden - exit
	if	( ! Serial.available() )
		return	( (uint8_t*) 0 );

	// Anfangspacket - ohne Inhalt
	int count = 0;
	while ( true )
	{
		if	( ! Serial.available() )
			continue;

		int i = Serial.read();
		if	( i == BIDIB_PKT_MAGIC )
		{
			if	( count == 0 )
				continue;
			break;
		}
		buf[count++] = i;
	}

	// Message Escapen (= ESC raus)
	int len = buf[0];
	deEscapeMessage( buf, len );

#if	( DEBUG_SCOPE > 1 )
	Serial3 << "receive: ";
	for	( int i = 2; i < len-1; i++ )
		Serial3 << hex(buf[i]) << ":";
	Serial3 << endl;
#endif
	return	( buf );
}

uint8_t buffer[64];

/**
 * Sendet die Message zurueck an den Host.
 */
int BiDiBInterfaceSerial::sendResponse( uint8_t* msg )
{
	int inLen = msg[0];
	int i = 0;

	buffer[0] = BIDIB_PKT_MAGIC;
	int outLen = 1;
    uint8_t tx_crc = 0;

	for ( i = 0; i <= inLen; i++ )
	{
		tx_crc = crc(msg[i], tx_crc );					// CRC berechnen

		if ( (msg[i] == BIDIB_PKT_MAGIC) || (msg[i] == BIDIB_PKT_ESCAPE) )
		{
			buffer[outLen++] = BIDIB_PKT_ESCAPE; // escape this char
			buffer[outLen++] = msg[i] ^ 0x20; // 'veraendern'
		}
		else
		{
			buffer[outLen++] = msg[i];
		}
	}
	buffer[outLen++] = tx_crc;
	buffer[outLen++] = BIDIB_PKT_MAGIC;

#if	( DEBUG_SCOPE > 1 )
	Serial3 << "send: " /*<< outLen << ", "*/;
	for	( i = 3; i < outLen-2; i++ )
		Serial3 << hex(buffer[i]);
	Serial3 << endl;
#endif

	Serial.write( buffer, outLen );
	Serial.flush();

	return	( outLen );
}

} /* namespace bidib */
