/**
 BiDiBSession - BiDiB Kommunikation

 Copyright (c) 2013 Marcel Bernet.  All right reserved.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "BiDiBSession.h"
#include <string.h>
#include <Streaming.h>

namespace bidib
{

/**
 * BiDiB Kommandos parsen und ausfuehren
 */
int BiDiBSession::dispatch( uint8_t* buf )
{
	// Command
	//srcp::command_t cmd;

	// Befehl abhandeln
	switch	( buf[2] )
	{
		// Get Hersteller Id (0x01)
		case MSG_SYS_GET_MAGIC:
			io->sendResponse( (uint8_t*) &bidib_sys_magic );
			index = 1;
			break;
		// Sys Enable (0x03)
        case MSG_SYS_ENABLE:
        	spontaneous_enabled = 1;
            break;
        // Sys Disable (0x04)
        case MSG_SYS_DISABLE:
        	spontaneous_enabled = 0;
            break;
	    // SW Version (0x06)
		case MSG_SYS_GET_SW_VERSION:
		{
			t_node_message10 msg10;
		    msg10.header.node_addr = 0;
		    msg10.header.index = getNextIndex();
		    msg10.header.msg_type = MSG_SYS_SW_VERSION;
		    msg10.data[0] = COMPILE_RUN;
		    msg10.data[1] = SUBVERSION;
		    msg10.data[2] = VERSION;
		    msg10.header.size = 3+3;
		    io->sendResponse( (uint8_t*) &msg10 );
		}
		    break;
		// Ping (0x07)
		case MSG_SYS_PING:
			sendOneParaResponse(MSG_SYS_PONG, 0);
			break;
		// Liefert die Anzahl Nodes (0x0B)
		case MSG_NODETAB_GETALL:
			node2send = 0;
			sendOneParaResponse(MSG_NODETAB_COUNT, 1 );
			break;
		// naechste Node lesen (0x0C)
		case MSG_NODETAB_GETNEXT:
			sendNodeTabEmpty();
			break;
	    // System Clock -startet u.a. die Macros - sendet nichts zurueck (0x18)
		case MSG_SYS_CLOCK:
			break;

	    // Abfragen der Anzahl Features (0x10)
		case MSG_FEATURE_GETALL:
			{
				lastSubSystem = subSystem;
				featureIndex = 0;
				int featureCount = 0;
				for ( BiDiBSubSystem* ss = subSystem; ss != 0; ss = ss->nextElement() )
					featureCount += ss->getFeatureCount();
				sendOneParaResponse(MSG_FEATURE_COUNT, featureCount );
			}
			break;

		// naechstes Feature abfragen (0x11)
		case MSG_FEATURE_GETNEXT:
			while	( 1 )
			{
				if	( lastSubSystem == 0 )
				{
					sendTwoParaResponse( MSG_FEATURE_NA, 255, 0 );
					lastSubSystem = subSystem;
					featureIndex = 0;
					return( 1 );
				}
				uint8_t* rc = lastSubSystem->getFeatureByIndex( featureIndex );
				if	( rc == (uint8_t*) 0 )
				{
					lastSubSystem = lastSubSystem->nextElement();
					featureIndex = 0;
					continue;
				}
#if	( DEBUG_SCOPE > 1 )
				Serial3 << "feature: " << rc[0] << " = " << rc[1] << endl;
#endif
				sendTwoParaResponse( MSG_FEATURE, rc[0], rc[1] );
				featureIndex++;
				break;
			}
			return( 1 );

		// Get Features/Eigenschaften des Arduinos (0x12)
		case MSG_FEATURE_GET:
			for ( BiDiBSubSystem* ss = subSystem; ss != 0; ss = ss->nextElement() )
			{
				uint8_t* rc;
				if	( (rc = ss->getFeature(buf[3])) != (uint8_t *) 0 )
				{
					sendTwoParaResponse( MSG_FEATURE, rc[0], rc[1] );
					return	( 1 );
				}
			}
			sendTwoParaResponse( MSG_FEATURE_NA, 255, 0 );
			return	( 1 );

	    // Set Features/Eigenschaften des Arduinos (0x13)
		case MSG_FEATURE_SET:
			for ( BiDiBSubSystem* ss = subSystem; ss != 0; ss = ss->nextElement() )
			{
				uint8_t* rc;
				if	( (rc = ss->setFeature(buf[3], buf[4])) != (uint8_t *) 0 )
				{
					sendTwoParaResponse( MSG_FEATURE, buf[3], rc[1] );
					return	( 1 );
				}
			}
			sendTwoParaResponse( MSG_FEATURE_NA, 255, 0 );
			return	( 1 );

		// Power OFF
		case MSG_BOOST_OFF:
			break;
		// Power On
		case MSG_BOOST_ON:
			break;
	}

	// weitere Befehle werden direkt in den Subsystemen abgehandelt
	for ( BiDiBSubSystem* ss = subSystem; ss != 0; ss = ss->nextElement() )
		ss->dispatch( buf );

	return	( 1 );
}

/**
 * Sendet genau ein Datenelement zurueck
 */
int BiDiBSession::sendOneParaResponse( uint8_t type, uint8_t data )
{
    t_node_message1 message;
    message.header.node_addr = 0;
    message.header.index = getNextIndex();
    message.header.msg_type = type;
    message.data = data;
    message.header.size = 3+1;
    return	( io->sendResponse( (uint8_t*) &message ) );
}

/**
 * Sendet genau zwei Datenelemente zurueck
 */
int BiDiBSession::sendTwoParaResponse( uint8_t type, uint8_t value1, uint8_t value2 )
{
	t_node_message2 message;
    message.header.node_addr = 0;
    message.header.index = getNextIndex();
    message.header.msg_type = type;
    message.data[0] = value1;
    message.data[1] = value2;
    message.header.size = 3+2;
    return	( io->sendResponse( (uint8_t*) &message ) );
}

/**
 * Liefert die Eigenschaften des Geraetes
 */
void BiDiBSession::sendNodeTabEmpty( void )
{
	if ( node2send == 0 )
	{
		node2send++;
		t_node_message18 message;
		message.header.node_addr = 0;
		message.header.index = getNextIndex();
		message.header.msg_type = MSG_NODETAB;
		message.data[0] = 1; // Version
		message.data[1] = 0; // local addr
		memcpy( &message.data[2], &myUniqueId, sizeof(myUniqueId) );
		message.header.size = 3 + 2 + sizeof(myUniqueId); // 3+9, 12 in total

		io->sendResponse( (uint8_t *) &message );
	}
	else
	{
		sendOneParaResponse( MSG_NODE_NA, 255 );
	}
}

/**
 * Liefert die naechste Index Nummer
 */
uint8_t BiDiBSession::getNextIndex( void )
{
	uint8_t rc;
	rc = index;
	index++;

	if ( index == 0 )
		index++;
	return (rc);
}


}
