/**
 BiDiBSession - BiDiB Kommunikation

 Copyright (c) 2013 Marcel Bernet.  All right reserved.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef BIDIBPARSER_H_
#define BIDIBPARSER_H_

#include <Arduino.h>
#include "bidib_messages.h"
#include "bidib_datatypes.h"
#include "BiDiBInterface.h"
#include "BiDiBSubSystem.h"
#include "../srcp/SRCPCommand.h"
#include "../srcp/SRCPDeviceManager.h"

namespace bidib
{

class BiDiBSession
{
private:
	// I/O Port
	BiDiBInterface* io;
	// Device Manager
	srcp::SRCPDeviceManager* manager;
	// Subsysteme
	BiDiBSubSystem* subSystem;
	// Message Nr. wird fortlaufend aufgezaehlt, bis Ueberlauf
	uint8_t index;
	// Counter fuer Senden der Anzahl Subnodes
	uint8_t node2send;
	// Spontane BiDiB Enabled
	int spontaneous_enabled;

	// Features durchlaufen
	BiDiBSubSystem* lastSubSystem;
	int featureIndex;

public:
	BiDiBSession( BiDiBInterface* input, srcp::SRCPDeviceManager* m ) { io = input; manager = m; index = 0; node2send = 0; }
	int dispatch( uint8_t* msg );
	uint8_t getNextIndex( void );
	int sendOneParaResponse( uint8_t type, uint8_t data );
	int sendTwoParaResponse( uint8_t type, uint8_t value1, uint8_t value2 );
	void sendNodeTabEmpty( void );
    int sendResponse( uint8_t* msg ) { return( io->sendResponse( msg ) ); }
	BiDiBInterface* getInterface() { return io; }
	srcp::SRCPDeviceManager* getManager() { return manager; }
	void addSubSystem( BiDiBSubSystem* subSystem ) { subSystem->setNextElement( this->subSystem ); this->subSystem = subSystem; }
	int isSpontaneousEnabled() { return spontaneous_enabled; }
};

}

// Externe Konstanten aus config.h
extern const bidib::t_bidib_myunique_id myUniqueId;
extern const uint8_t bidib_sys_magic[];

#endif /* BIDIBPARSER_H_ */
