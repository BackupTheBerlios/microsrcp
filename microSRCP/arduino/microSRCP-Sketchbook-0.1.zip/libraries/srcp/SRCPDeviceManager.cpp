/*
	SRCPDeviceManager leitet die SRCP Befehle an die Geraete weiter

	Siehe auch: http://srcpd.sourceforge.net/srcp/

	Copyright (c) 2012 Marcel Bernet.  All right reserved.

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "SRCPDeviceManager.h"

#include "SRCPGenericAccessoire.h"
#include "SRCPDevice.h"

namespace srcp
{

SRCPDeviceManager::SRCPDeviceManager( srcp::SRCPDevice *devices[] )
{
	this->devices = devices;
}

int SRCPDeviceManager::dispatch( command_t& cmd )
{
	switch (cmd.cmd)
	{
		// Power ON
		case	GO:
			for	( int i = 0; devices[i] != (srcp::SRCPDevice*) 0; i++ )
				devices[i]->setPower( 1 );
			break;

		// Setzen oder holen von Geraete Werten
		case SET:
		case GET:
			for	( int i = 0; devices[i] != (srcp::SRCPDevice*) 0; i++ )
			{
				// nicht angeforderte Geraete ueberspringen
				if	( devices[i]->getType() != cmd.device )
					continue;
				// Adresse trifft nicht zu, ueberspringen
				if	( devices[i]->checkAddr( cmd.addr ) == 0 )
					continue;

				if	( cmd.cmd == SET )
					cmd.values[0] = devices[i]->set( cmd );
				else
					cmd.values[0] = devices[i]->get( cmd.addr );
			}
			break;

		// Power OFF
		case	TERM:
		case	RESET:
			for	( int i = 0; devices[i] != (srcp::SRCPDevice*) 0; i++ )
				devices[i]->setPower( 0 );
			break;
	}

	return	( cmd.values[0] );

}

void SRCPDeviceManager::refresh()
{
	for	( int i = 0; devices[i] != (srcp::SRCPDevice*) 0; i++ )
	{
		if	( devices[i]->getType() == FB )
			devices[i]->refresh();
	}
}

} /* namespace srcp */
